import { createClient } from "@/lib/supabase/server"

export async function POST(req: Request) {
  const { subject, topic, score, totalQuestions, questions } = await req.json()

  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) {
    return Response.json({ error: "Non authentifié" }, { status: 401 })
  }

  const { data, error } = await supabase
    .from("quiz_results")
    .insert({
      user_id: user.id,
      subject,
      topic,
      score,
      total_questions: totalQuestions,
      questions,
    })
    .select()
    .single()

  if (error) {
    return Response.json({ error: error.message }, { status: 500 })
  }

  return Response.json({ result: data })
}
