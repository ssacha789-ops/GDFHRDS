import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { ProgressClient } from "@/components/progress/progress-client"
import { subjects } from "@/lib/subjects"

export default async function ProgressPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  
  if (!user) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", user.id)
    .single()

  const { data: quizResults } = await supabase
    .from("quiz_results")
    .select("*")
    .eq("user_id", user.id)
    .order("created_at", { ascending: false })

  // Calculate stats per subject
  const subjectStats = subjects.map(subject => {
    const subjectQuizzes = quizResults?.filter(q => q.subject === subject.id) || []
    const totalQuizzes = subjectQuizzes.length
    const totalScore = subjectQuizzes.reduce((acc, q) => acc + q.score, 0)
    const totalQuestions = subjectQuizzes.reduce((acc, q) => acc + q.total_questions, 0)
    const averageScore = totalQuestions > 0 ? Math.round((totalScore / totalQuestions) * 100) : 0

    return {
      ...subject,
      totalQuizzes,
      averageScore,
      recentQuizzes: subjectQuizzes.slice(0, 5)
    }
  })

  return (
    <ProgressClient 
      profile={profile}
      subjectStats={subjectStats}
      recentQuizzes={quizResults?.slice(0, 10) || []}
    />
  )
}
