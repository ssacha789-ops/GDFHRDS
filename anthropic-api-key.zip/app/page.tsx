import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { 
  BookOpen, 
  Sparkles, 
  Brain, 
  Trophy, 
  MessageSquare,
  Calculator,
  FlaskConical,
  BookText,
  Globe,
  Map,
  ArrowRight,
  CheckCircle
} from "lucide-react"

const features = [
  {
    icon: Brain,
    title: "Assistant IA intelligent",
    description: "Un tuteur personnel qui explique les cours, répond à vos questions et s'adapte à votre niveau."
  },
  {
    icon: Trophy,
    title: "Quiz personnalisés",
    description: "Des quiz générés par IA pour tester vos connaissances et identifier vos points faibles."
  },
  {
    icon: MessageSquare,
    title: "Correction intelligente",
    description: "Des explications détaillées pour comprendre vos erreurs et progresser rapidement."
  }
]

const subjects = [
  { icon: Calculator, name: "Maths", color: "from-blue-500 to-cyan-500" },
  { icon: FlaskConical, name: "Sciences", color: "from-emerald-500 to-teal-500" },
  { icon: BookText, name: "Français", color: "from-rose-500 to-pink-500" },
  { icon: Globe, name: "Anglais", color: "from-amber-500 to-orange-500" },
  { icon: Map, name: "Histoire-Géo", color: "from-violet-500 to-purple-500" },
]

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="mx-auto max-w-7xl px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-accent">
              <BookOpen className="h-5 w-5 text-accent-foreground" />
            </div>
            <div>
              <h1 className="font-bold text-foreground">SchoolPilot</h1>
              <p className="text-xs text-muted-foreground">Plateforme de révision</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Link href="/auth/login">
              <Button variant="ghost" size="sm">Connexion</Button>
            </Link>
            <Link href="/auth/sign-up">
              <Button size="sm" className="bg-accent text-accent-foreground hover:bg-accent/90">
                Commencer
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="mx-auto max-w-4xl text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/10 border border-accent/20 mb-6">
            <Sparkles className="h-4 w-4 text-accent" />
            <span className="text-sm text-accent">Propulsé par l&apos;intelligence artificielle</span>
          </div>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-foreground mb-6 text-balance">
            Révisez plus intelligemment avec votre tuteur IA
          </h2>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto text-pretty">
            SchoolPilot est votre compagnon de révision intelligent. Posez vos questions, 
            générez des quiz personnalisés, et progressez à votre rythme dans toutes les matières.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/auth/sign-up">
              <Button size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90 w-full sm:w-auto">
                Créer un compte gratuit
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
            <Link href="/auth/login">
              <Button size="lg" variant="outline" className="w-full sm:w-auto">
                J&apos;ai déjà un compte
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Subjects Section */}
      <section className="py-12 px-4 bg-card/30">
        <div className="mx-auto max-w-7xl">
          <p className="text-center text-sm text-muted-foreground mb-6">
            Toutes les matières du collège au supérieur
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            {subjects.map((subject) => (
              <div 
                key={subject.name}
                className="flex items-center gap-2 px-4 py-2 rounded-full bg-card border border-border"
              >
                <div className={`flex h-6 w-6 items-center justify-center rounded-full bg-gradient-to-br ${subject.color}`}>
                  <subject.icon className="h-3 w-3 text-white" />
                </div>
                <span className="text-sm font-medium text-foreground">{subject.name}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4">
        <div className="mx-auto max-w-7xl">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-foreground mb-4">
              Tout ce dont vous avez besoin pour réussir
            </h3>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Une plateforme complète qui combine intelligence artificielle et pédagogie 
              pour vous accompagner dans vos révisions.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {features.map((feature) => (
              <Card key={feature.title} className="bg-card border-border">
                <CardContent className="p-6">
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-accent/20 mb-4">
                    <feature.icon className="h-6 w-6 text-accent" />
                  </div>
                  <h4 className="text-lg font-semibold text-card-foreground mb-2">
                    {feature.title}
                  </h4>
                  <p className="text-sm text-muted-foreground">
                    {feature.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 px-4 bg-card/30">
        <div className="mx-auto max-w-4xl">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-foreground mb-4">
              Pourquoi choisir SchoolPilot ?
            </h3>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {[
              "Disponible 24h/24, 7j/7",
              "S'adapte à votre niveau",
              "Explications personnalisées",
              "Quiz illimités",
              "Suivi de progression",
              "5 matières principales"
            ].map((benefit) => (
              <div key={benefit} className="flex items-center gap-3 p-4 rounded-lg bg-card border border-border">
                <CheckCircle className="h-5 w-5 text-accent flex-shrink-0" />
                <span className="text-foreground">{benefit}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4">
        <div className="mx-auto max-w-3xl text-center">
          <div className="p-8 rounded-2xl bg-gradient-to-br from-accent/20 to-accent/5 border border-accent/20">
            <h3 className="text-2xl font-bold text-foreground mb-4">
              Prêt à améliorer vos résultats ?
            </h3>
            <p className="text-muted-foreground mb-6">
              Rejoignez SchoolPilot et commencez à réviser intelligemment dès aujourd&apos;hui.
            </p>
            <Link href="/auth/sign-up">
              <Button size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90">
                Commencer gratuitement
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8 px-4">
        <div className="mx-auto max-w-7xl flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <BookOpen className="h-5 w-5 text-accent" />
            <span className="font-semibold text-foreground">SchoolPilot</span>
          </div>
          <p className="text-sm text-muted-foreground">
            &copy; {new Date().getFullYear()} SchoolPilot. Tous droits réservés.
          </p>
        </div>
      </footer>
    </div>
  )
}
