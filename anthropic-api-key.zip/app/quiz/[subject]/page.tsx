import { redirect, notFound } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { subjects } from "@/lib/subjects"
import { QuizClient } from "@/components/quiz/quiz-client"

interface QuizPageProps {
  params: Promise<{ subject: string }>
}

export default async function QuizPage({ params }: QuizPageProps) {
  const { subject: subjectId } = await params
  
  const subject = subjects.find(s => s.id === subjectId)
  if (!subject) {
    notFound()
  }

  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  
  if (!user) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase
    .from("profiles")
    .select("level")
    .eq("id", user.id)
    .single()

  return (
    <QuizClient 
      subject={subject}
      userLevel={profile?.level || "lycee"}
    />
  )
}
