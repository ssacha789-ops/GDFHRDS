import Link from "next/link"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { AlertCircle } from "lucide-react"

export default function AuthErrorPage() {
  return (
    <div className="flex min-h-screen items-center justify-center p-4">
      <Card className="w-full max-w-md border-border bg-card text-center">
        <CardHeader className="space-y-4">
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-xl bg-destructive/10">
            <AlertCircle className="h-6 w-6 text-destructive" />
          </div>
          <div>
            <CardTitle className="text-2xl font-bold text-card-foreground">
              Erreur d&apos;authentification
            </CardTitle>
            <CardDescription className="text-muted-foreground">
              Une erreur s&apos;est produite lors de la connexion
            </CardDescription>
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">
            Veuillez réessayer ou contacter le support si le problème persiste.
          </p>
        </CardContent>
        <CardFooter className="flex gap-2">
          <Button asChild variant="outline" className="flex-1">
            <Link href="/auth/login">Se connecter</Link>
          </Button>
          <Button asChild className="flex-1 bg-accent text-accent-foreground hover:bg-accent/90">
            <Link href="/auth/sign-up">Créer un compte</Link>
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
