import Link from "next/link"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Mail, BookOpen } from "lucide-react"

export default function SignUpSuccessPage() {
  return (
    <div className="flex min-h-screen items-center justify-center p-4">
      <Card className="w-full max-w-md border-border bg-card text-center">
        <CardHeader className="space-y-4">
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-xl bg-accent">
            <Mail className="h-6 w-6 text-accent-foreground" />
          </div>
          <div>
            <CardTitle className="text-2xl font-bold text-card-foreground">
              Vérifiez votre email
            </CardTitle>
            <CardDescription className="text-muted-foreground">
              Nous vous avons envoyé un lien de confirmation
            </CardDescription>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">
            Cliquez sur le lien dans l&apos;email pour activer votre compte et commencer à réviser.
          </p>
          <div className="rounded-lg border border-border bg-secondary/50 p-4">
            <div className="flex items-center gap-3">
              <BookOpen className="h-5 w-5 text-accent" />
              <p className="text-sm text-card-foreground">
                Une fois confirmé, vous aurez accès à toutes les matières et à l&apos;assistant IA.
              </p>
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <Button asChild variant="outline" className="w-full">
            <Link href="/auth/login">Retour à la connexion</Link>
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
