# étude.ai 🎓

Application web moderne de révision scolaire propulsée par l'IA Claude.

## Fonctionnalités

- 🏠 **Page d'accueil** — design noir et blanc, animations, responsive mobile
- 🔐 **Connexion / Inscription** — système d'authentification UI complet
- 📚 **Espace utilisateur** — coller un cours, générer du contenu IA
- ◈  **Résumé automatique** — résumé structuré du cours
- ◉  **Quiz interactif** — 5 QCM générés automatiquement
- ◫  **Fiche de révision** — fiche structurée avec concepts et définitions

## Stack

- **Next.js 14** (App Router)
- **React 18**
- **CSS vanilla** (aucune dépendance UI)
- **API Anthropic Claude** (`claude-sonnet-4-20250514`)

## Installation

```bash
# 1. Cloner le repo
git clone https://github.com/TON-USERNAME/etude-ai.git
cd etude-ai

# 2. Installer les dépendances
npm install

# 3. Lancer en développement
npm run dev
```

Ouvrir [http://localhost:3000](http://localhost:3000)

## Structure

```
etude-ai/
├── app/
│   ├── layout.js      # Layout racine Next.js
│   └── page.jsx       # APPLICATION COMPLÈTE (tout dans un seul fichier)
├── next.config.js
├── package.json
└── README.md
```

## Note sur l'API

L'app appelle directement `https://api.anthropic.com/v1/messages` depuis le navigateur.
En production, il est recommandé de créer une route API Next.js pour protéger ta clé :

```
app/api/generate/route.js
```

Et d'y ajouter la variable d'environnement :
```
ANTHROPIC_API_KEY=sk-ant-...
```

## Déploiement (Vercel)

```bash
npx vercel
```

---

Made with ❤️ pour les étudiants
