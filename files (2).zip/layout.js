export const metadata = {
  title: "étude.ai — Révision intelligente",
  description: "Résumés, quiz et fiches de révision générés par IA en quelques secondes.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="fr">
      <body>{children}</body>
    </html>
  );
}
