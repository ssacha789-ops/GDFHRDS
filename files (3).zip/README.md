# étude.ai 🎓

Application web de révision scolaire propulsée par Claude (Anthropic).

## Structure du projet

```
etude-ai/
├── app/
│   ├── api/
│   │   └── generate/
│   │       └── route.js   ← Route API serveur (appelle Anthropic)
│   ├── layout.js
│   └── page.jsx           ← Interface complète
├── .env.local             ← Ta clé API (à créer, ne pas push)
├── .env.local.example     ← Modèle à copier
├── .gitignore
├── next.config.js
└── package.json
```

## Installation locale

```bash
# 1. Cloner
git clone https://github.com/TON-USERNAME/etude-ai.git
cd etude-ai

# 2. Installer les dépendances
npm install

# 3. Créer le fichier de configuration
cp .env.local.example .env.local
# → Ouvre .env.local et remplace par ta vraie clé Anthropic

# 4. Lancer
npm run dev
# → http://localhost:3000
```

## Déploiement sur Vercel

### Étape 1 — Push sur GitHub
```bash
git add .
git commit -m "initial commit"
git push origin main
```

### Étape 2 — Déployer sur Vercel
1. Va sur [vercel.com](https://vercel.com) → "New Project"
2. Importe ton repo GitHub
3. **IMPORTANT** : Dans "Environment Variables", ajoute :
   - Nom : `ANTHROPIC_API_KEY`
   - Valeur : ta clé `sk-ant-...` (depuis [console.anthropic.com](https://console.anthropic.com))
4. Clique "Deploy"

> ⚠️ Sans la variable `ANTHROPIC_API_KEY` sur Vercel, l'IA ne fonctionnera pas.

## Obtenir une clé API Anthropic

1. Crée un compte sur [console.anthropic.com](https://console.anthropic.com)
2. Va dans "API Keys" → "Create Key"
3. Copie la clé (commence par `sk-ant-`)
4. Colle-la dans `.env.local` en local, et dans Vercel en production

---

Made with ❤️ pour les étudiants
