import { NextResponse } from "next/server";

export async function POST(request) {
  try {
    const { type, courseText } = await request.json();

    if (!courseText || !type) {
      return NextResponse.json({ error: "Champs manquants." }, { status: 400 });
    }

    const prompts = {
      summary: `Résume ce cours clairement en français. Utilise ## pour les titres et **gras** pour les points importants.\n\nCours:\n${courseText}`,
      quiz:    `Crée 5 questions à choix multiples (A/B/C/D) basées sur ce cours en français. Numérote les questions. Indique les bonnes réponses à la fin.\n\nCours:\n${courseText}`,
      fiche:   `Crée une fiche de révision structurée en français. Sections ## : Concepts Clés, Définitions, Points à Retenir, À Savoir Absolument.\n\nCours:\n${courseText}`,
    };

    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 1000,
        messages: [{ role: "user", content: prompts[type] }],
      }),
    });

    if (!res.ok) {
      const err = await res.json();
      return NextResponse.json({ error: err.error?.message || "Erreur API." }, { status: res.status });
    }

    const data = await res.json();
    const text = (data.content || []).map((b) => b.text || "").join("") || "Aucune réponse.";

    return NextResponse.json({ text });
  } catch (err) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
