"use client";
import { useState } from "react";

// ─── STYLES ──────────────────────────────────────────────────────────────────
const CSS = `
  @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&display=swap');

  *, *::before, *::after { margin: 0; padding: 0; box-sizing: border-box; }
  body { background: #070707; color: #efefef; font-family: 'Syne', sans-serif; overflow-x: hidden; }

  .btn { padding: .6rem 1.4rem; border-radius: 6px; font-family: 'Syne', sans-serif; font-size: .875rem; font-weight: 600; cursor: pointer; transition: all .15s; border: 1px solid transparent; }
  .btn-ghost   { background: transparent; color: #efefef; border-color: #2a2a2a; }
  .btn-ghost:hover { border-color: #555; background: #111; }
  .btn-primary { background: #efefef; color: #070707; }
  .btn-primary:hover { background: #fff; transform: translateY(-1px); }
  .btn-primary:active { transform: translateY(0); }
  .btn-lg { padding: .85rem 2rem; font-size: 1rem; }
  .btn-sm { padding: .4rem .9rem; font-size: .78rem; }

  .page-enter { animation: fadeIn .3s ease; }

  @keyframes fadeIn  { from { opacity:0; transform:translateY(10px); } to { opacity:1; transform:translateY(0); } }
  @keyframes pulse   { 0%,100%{background:#222;transform:scale(1);} 50%{background:#888;transform:scale(1.4);} }

  /* NAV */
  .nav { display:flex; justify-content:space-between; align-items:center; padding:1.4rem 2.5rem; border-bottom:1px solid #141414; }
  .logo { font-size:1.15rem; font-weight:800; letter-spacing:-.03em; cursor:pointer; }
  .logo span { color:#333; }
  .nav-actions { display:flex; gap:.75rem; }

  /* HERO */
  .hero { max-width:860px; margin:0 auto; padding:7rem 2rem 5rem; text-align:center; }
  .badge { display:inline-block; padding:.3rem .9rem; background:#0f0f0f; border:1px solid #1e1e1e; border-radius:100px; font-size:.72rem; color:#555; letter-spacing:.07em; text-transform:uppercase; margin-bottom:2rem; }
  .hero h1 { font-size:clamp(2.6rem,7vw,4.8rem); font-weight:800; line-height:1.04; letter-spacing:-.04em; margin-bottom:1.5rem; }
  .hero h1 em { color:#333; font-style:normal; }
  .hero p  { font-size:1.05rem; color:#666; max-width:460px; margin:0 auto 3rem; line-height:1.8; }
  .hero-btns { display:flex; gap:1rem; justify-content:center; flex-wrap:wrap; }

  /* FEATURES */
  .features { max-width:1000px; margin:0 auto; padding:3rem 2rem 7rem; }
  .feat-label { font-size:.72rem; letter-spacing:.1em; text-transform:uppercase; color:#333; text-align:center; margin-bottom:2.5rem; }
  .feat-grid  { display:grid; grid-template-columns:repeat(3,1fr); border:1px solid #141414; border-radius:12px; overflow:hidden; }
  .feat-card  { padding:2.2rem; background:#0b0b0b; transition:background .2s; border-right:1px solid #141414; }
  .feat-card:last-child { border-right:none; }
  .feat-card:hover { background:#0f0f0f; }
  .feat-icon  { width:40px; height:40px; display:flex; align-items:center; justify-content:center; background:#111; border:1px solid #1e1e1e; border-radius:9px; margin-bottom:1.2rem; font-size:1.1rem; }
  .feat-card h3 { font-size:.95rem; font-weight:700; margin-bottom:.5rem; }
  .feat-card p  { font-size:.82rem; color:#555; line-height:1.7; }

  /* AUTH */
  .auth-wrap  { min-height:100vh; display:flex; align-items:center; justify-content:center; padding:2rem; }
  .auth-card  { width:100%; max-width:410px; background:#0b0b0b; border:1px solid #1a1a1a; border-radius:14px; padding:2.5rem; }
  .auth-logo  { font-size:1rem; font-weight:800; margin-bottom:2rem; cursor:pointer; letter-spacing:-.02em; }
  .auth-logo span { color:#333; }
  .auth-title { font-size:1.4rem; font-weight:800; margin-bottom:.4rem; letter-spacing:-.02em; }
  .auth-sub   { font-size:.82rem; color:#555; margin-bottom:1.8rem; line-height:1.6; }
  .field { margin-bottom:.9rem; }
  .field label { display:block; font-size:.75rem; color:#555; margin-bottom:.35rem; font-weight:600; letter-spacing:.04em; text-transform:uppercase; }
  .field input { width:100%; padding:.75rem 1rem; background:#111; border:1px solid #1e1e1e; border-radius:8px; color:#efefef; font-family:'Syne',sans-serif; font-size:.875rem; outline:none; transition:border-color .15s; }
  .field input:focus { border-color:#333; }
  .field input::placeholder { color:#2a2a2a; }
  .auth-err   { color:#e24b4a; font-size:.78rem; margin-bottom:.8rem; }
  .auth-switch { font-size:.78rem; color:#444; text-align:center; margin-top:1.4rem; }
  .auth-switch button { background:none; border:none; color:#efefef; cursor:pointer; font-family:'Syne',sans-serif; text-decoration:underline; font-size:.78rem; }

  /* DASHBOARD */
  .dash      { display:flex; flex-direction:column; min-height:100vh; }
  .dash-nav  { padding:1.1rem 2rem; display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid #141414; position:sticky; top:0; background:rgba(7,7,7,.92); backdrop-filter:blur(12px); z-index:10; }
  .dash-logo { font-size:.95rem; font-weight:800; letter-spacing:-.02em; }
  .dash-logo span { color:#222; }
  .dash-user { display:flex; align-items:center; gap:.8rem; }
  .avatar    { width:30px; height:30px; border-radius:50%; background:#161616; border:1px solid #2a2a2a; display:flex; align-items:center; justify-content:center; font-size:.7rem; font-weight:700; color:#777; }
  .uname     { font-size:.82rem; color:#555; }
  .btn-lo    { background:none; border:1px solid #1a1a1a; border-radius:5px; padding:.3rem .75rem; color:#444; font-family:'Syne',sans-serif; font-size:.72rem; cursor:pointer; transition:all .15s; }
  .btn-lo:hover { border-color:#333; color:#888; }
  .dash-main  { flex:1; max-width:820px; width:100%; margin:0 auto; padding:2.5rem 2rem; }
  .greeting   { font-size:1.5rem; font-weight:800; letter-spacing:-.03em; margin-bottom:.4rem; }
  .dash-sub   { font-size:.82rem; color:#444; margin-bottom:2.5rem; }
  .course-box { background:#0b0b0b; border:1px solid #161616; border-radius:11px; overflow:hidden; margin-bottom:1.2rem; }
  .course-hd  { padding:.9rem 1.3rem; border-bottom:1px solid #161616; display:flex; justify-content:space-between; align-items:center; }
  .course-hd-lbl { font-size:.7rem; font-weight:700; text-transform:uppercase; letter-spacing:.1em; color:#333; }
  .course-ta  { width:100%; min-height:200px; background:transparent; border:none; outline:none; padding:1.3rem; color:#ccc; font-family:'Syne',sans-serif; font-size:.875rem; line-height:1.8; resize:vertical; }
  .course-ta::placeholder { color:#1e1e1e; }
  .actions    { display:grid; grid-template-columns:repeat(3,1fr); gap:.75rem; margin-bottom:2rem; }
  .abt        { padding:1rem; background:#0b0b0b; border:1px solid #161616; border-radius:9px; color:#efefef; font-family:'Syne',sans-serif; font-size:.8rem; font-weight:600; cursor:pointer; transition:all .15s; display:flex; flex-direction:column; align-items:center; gap:.45rem; }
  .abt:hover:not(:disabled) { background:#111; border-color:#2a2a2a; transform:translateY(-2px); }
  .abt:active:not(:disabled) { transform:translateY(0); }
  .abt:disabled { opacity:.35; cursor:not-allowed; }
  .abt-ic     { font-size:1.1rem; }
  .api-error  { background:#140a0a; border:1px solid #3a1515; border-radius:9px; padding:1rem 1.3rem; font-size:.82rem; color:#e24b4a; margin-bottom:1.5rem; display:flex; align-items:center; gap:.6rem; }
  .res-box    { background:#0b0b0b; border:1px solid #161616; border-radius:11px; overflow:hidden; animation:fadeIn .35s ease; }
  .res-hd     { padding:.9rem 1.3rem; border-bottom:1px solid #161616; display:flex; justify-content:space-between; align-items:center; }
  .res-badge  { font-size:.68rem; font-weight:700; text-transform:uppercase; letter-spacing:.1em; padding:.2rem .7rem; border-radius:100px; background:#141414; color:#555; border:1px solid #1e1e1e; }
  .res-body   { padding:1.3rem; font-size:.85rem; line-height:1.9; color:#bbb; white-space:pre-wrap; word-wrap:break-word; max-height:420px; overflow-y:auto; }
  .res-body h1 { color:#efefef; font-size:1rem; font-weight:800; margin:1rem 0 .5rem; }
  .res-body h2 { color:#efefef; font-size:.92rem; font-weight:700; margin:1.2rem 0 .4rem; }
  .res-body strong { color:#efefef; font-weight:700; }
  .res-body::-webkit-scrollbar { width:4px; }
  .res-body::-webkit-scrollbar-track { background:transparent; }
  .res-body::-webkit-scrollbar-thumb { background:#222; border-radius:4px; }
  .loader     { display:flex; flex-direction:column; align-items:center; justify-content:center; padding:2.5rem; gap:.8rem; }
  .dots       { display:flex; gap:5px; }
  .dot        { width:5px; height:5px; border-radius:50%; background:#222; animation:pulse 1.2s ease-in-out infinite; }
  .dot:nth-child(2) { animation-delay:.2s; }
  .dot:nth-child(3) { animation-delay:.4s; }
  .loader-txt { font-size:.75rem; color:#333; }
  .dash-foot  { padding:1.2rem 2rem; border-top:1px solid #0f0f0f; text-align:center; }
  .dash-foot span { font-size:.72rem; color:#222; }

  @media (max-width:600px) {
    .nav      { padding:1rem 1.2rem; }
    .hero     { padding:4rem 1.2rem 3rem; }
    .hero h1  { font-size:2.4rem; }
    .features { padding:2rem 1.2rem 4rem; }
    .feat-grid { grid-template-columns:1fr; }
    .feat-card { border-right:none; border-bottom:1px solid #141414; }
    .feat-card:last-child { border-bottom:none; }
    .dash-main { padding:1.8rem 1.2rem; }
    .actions   { grid-template-columns:1fr; }
    .nav-actions .btn:first-child { display:none; }
    .uname     { display:none; }
  }
`;

// ─── RESULT RENDERER ─────────────────────────────────────────────────────────
function ResultBody({ text }) {
  return (
    <div className="res-body">
      {text.split("\n").map((line, i) => {
        if (line.startsWith("## ")) return <h2 key={i}>{line.slice(3)}</h2>;
        if (line.startsWith("# "))  return <h1 key={i}>{line.slice(2)}</h1>;
        if (line === "") return <br key={i} />;
        const parts = line.split(/\*\*(.*?)\*\*/g);
        const indent = line.startsWith("- ") || line.startsWith("• ") || /^\d+\./.test(line);
        return (
          <p key={i} style={{ marginBottom: ".3rem", paddingLeft: indent ? "1rem" : "0", color: indent ? "#999" : "#bbb" }}>
            {parts.map((p, j) => j % 2 === 1 ? <strong key={j}>{p}</strong> : p)}
          </p>
        );
      })}
    </div>
  );
}

// ─── APP ─────────────────────────────────────────────────────────────────────
export default function App() {
  const [page,        setPage]        = useState("landing");
  const [user,        setUser]        = useState(null);
  const [authMode,    setAuthMode]    = useState("login");
  const [form,        setForm]        = useState({ name: "", email: "", password: "" });
  const [formError,   setFormError]   = useState("");
  const [courseText,  setCourseText]  = useState("");
  const [result,      setResult]      = useState(null);
  const [loading,     setLoading]     = useState(false);
  const [loadingType, setLoadingType] = useState("");
  const [apiError,    setApiError]    = useState("");
  const [copied,      setCopied]      = useState(false);

  const navigate = (p) => { setPage(p); setFormError(""); setApiError(""); };

  // ── Auth ───────────────────────────────────────────────────────────────────
  const handleAuth = (e) => {
    e.preventDefault();
    if (!form.email || !form.password) { setFormError("Remplis tous les champs."); return; }
    if (authMode === "register" && !form.name) { setFormError("Entre ton prénom."); return; }
    setUser({ name: form.name || form.email.split("@")[0], email: form.email });
    navigate("dashboard");
  };

  // ── AI call via /api/generate ──────────────────────────────────────────────
  const callAI = async (type) => {
    if (!courseText.trim()) return;
    setLoading(true);
    setLoadingType(type);
    setResult(null);
    setApiError("");

    try {
      const res = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type, courseText }),
      });

      const data = await res.json();

      if (!res.ok || data.error) {
        setApiError(data.error || "Erreur lors de la génération.");
      } else {
        const labels = { summary: "Résumé", quiz: "Quiz", fiche: "Fiche de révision" };
        setResult({ type, label: labels[type], content: data.text });
      }
    } catch (err) {
      setApiError("Impossible de contacter le serveur : " + err.message);
    }

    setLoading(false);
  };

  const copyResult = () => {
    if (!result) return;
    navigator.clipboard?.writeText(result.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const typeIcons = { summary: "◈ Résumé", quiz: "◉ Quiz", fiche: "◫ Fiche de révision" };
  const loaderMsg = { summary: "Résumé en cours...", quiz: "Quiz en cours de création...", fiche: "Fiche en cours de génération..." };

  // ═══════════════════════════════════════════════════════════════════════════
  // LANDING
  // ═══════════════════════════════════════════════════════════════════════════
  if (page === "landing") return (
    <>
      <style>{CSS}</style>
      <div className="page-enter">
        <nav className="nav">
          <div className="logo">étude<span>.ai</span></div>
          <div className="nav-actions">
            <button className="btn btn-ghost"   onClick={() => { setAuthMode("login");    navigate("auth"); }}>Connexion</button>
            <button className="btn btn-primary" onClick={() => { setAuthMode("register"); navigate("auth"); }}>S&apos;inscrire</button>
          </div>
        </nav>

        <section className="hero">
          <div className="badge">✦ Révision intelligente · 2026</div>
          <h1>Révise plus vite.<br /><em>Retiens mieux.</em></h1>
          <p>Colle ton cours, et laisse l&apos;IA créer des résumés, quiz et fiches de révision en quelques secondes.</p>
          <div className="hero-btns">
            <button className="btn btn-primary btn-lg" onClick={() => { setAuthMode("register"); navigate("auth"); }}>
              Commencer gratuitement →
            </button>
            <button className="btn btn-ghost btn-lg" onClick={() => { setAuthMode("login"); navigate("auth"); }}>
              Se connecter
            </button>
          </div>
        </section>

        <section className="features">
          <p className="feat-label">Ce que tu peux faire</p>
          <div className="feat-grid">
            {[
              { icon: "◈", title: "Résumé automatique",  desc: "Transforme n'importe quel cours en résumé clair et structuré, avec les points essentiels mis en avant." },
              { icon: "◉", title: "Quiz interactif",     desc: "Génère un quiz personnalisé à partir de ton cours pour tester tes connaissances et repérer tes lacunes." },
              { icon: "◫", title: "Fiche de révision",   desc: "Crée une fiche complète avec définitions, concepts clés et points importants à mémoriser." },
            ].map((f) => (
              <div className="feat-card" key={f.title}>
                <div className="feat-icon">{f.icon}</div>
                <h3>{f.title}</h3>
                <p>{f.desc}</p>
              </div>
            ))}
          </div>
        </section>
      </div>
    </>
  );

  // ═══════════════════════════════════════════════════════════════════════════
  // AUTH
  // ═══════════════════════════════════════════════════════════════════════════
  if (page === "auth") return (
    <>
      <style>{CSS}</style>
      <div className="page-enter">
        <div className="auth-wrap">
          <div className="auth-card">
            <div className="auth-logo" onClick={() => navigate("landing")}>étude<span>.ai</span></div>
            <h1 className="auth-title">{authMode === "login" ? "Bon retour 👋" : "Crée ton compte"}</h1>
            <p className="auth-sub">
              {authMode === "login" ? "Connecte-toi pour accéder à ton espace." : "Commence à réviser intelligemment."}
            </p>

            <form onSubmit={handleAuth}>
              {authMode === "register" && (
                <div className="field">
                  <label>Prénom</label>
                  <input type="text" placeholder="Ton prénom" value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })} />
                </div>
              )}
              <div className="field">
                <label>Email</label>
                <input type="email" placeholder="ton@email.com" value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })} />
              </div>
              <div className="field" style={{ marginBottom: "1.3rem" }}>
                <label>Mot de passe</label>
                <input type="password" placeholder="••••••••" value={form.password}
                  onChange={(e) => setForm({ ...form, password: e.target.value })} />
              </div>
              {formError && <p className="auth-err">{formError}</p>}
              <button type="submit" className="btn btn-primary" style={{ width: "100%", padding: ".85rem" }}>
                {authMode === "login" ? "Se connecter →" : "Créer mon compte →"}
              </button>
            </form>

            <div className="auth-switch">
              {authMode === "login" ? (
                <>Pas encore de compte ?{" "}
                  <button onClick={() => { setAuthMode("register"); setFormError(""); }}>S&apos;inscrire</button>
                </>
              ) : (
                <>Déjà un compte ?{" "}
                  <button onClick={() => { setAuthMode("login"); setFormError(""); }}>Se connecter</button>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );

  // ═══════════════════════════════════════════════════════════════════════════
  // DASHBOARD
  // ═══════════════════════════════════════════════════════════════════════════
  return (
    <>
      <style>{CSS}</style>
      <div className="dash page-enter">
        <nav className="dash-nav">
          <div className="dash-logo">étude<span>.ai</span></div>
          <div className="dash-user">
            <div className="avatar">{user?.name?.[0]?.toUpperCase()}</div>
            <span className="uname">{user?.name}</span>
            <button className="btn-lo" onClick={() => {
              setUser(null); setCourseText(""); setResult(null); navigate("landing");
            }}>
              Déconnexion
            </button>
          </div>
        </nav>

        <main className="dash-main">
          <h1 className="greeting">Salut, {user?.name} 👋</h1>
          <p className="dash-sub">Colle ton cours ci-dessous et choisis ce que tu veux générer.</p>

          <div className="course-box">
            <div className="course-hd">
              <span className="course-hd-lbl">Ton cours</span>
              <button className="btn btn-sm btn-ghost" onClick={() => { setCourseText(""); setResult(null); setApiError(""); }}>
                Effacer
              </button>
            </div>
            <textarea
              className="course-ta"
              placeholder="Colle ton cours ici... (PDF, notes, site web)"
              value={courseText}
              onChange={(e) => setCourseText(e.target.value)}
            />
          </div>

          <div className="actions">
            {[
              { type: "summary", icon: "◈", label: "Résumer" },
              { type: "quiz",    icon: "◉", label: "Créer un quiz" },
              { type: "fiche",   icon: "◫", label: "Fiche de révision" },
            ].map(({ type, icon, label }) => (
              <button key={type} className="abt"
                disabled={!courseText.trim() || loading}
                onClick={() => callAI(type)}
              >
                <span className="abt-ic">{icon}</span>
                <span>{loading && loadingType === type ? "Génération..." : label}</span>
              </button>
            ))}
          </div>

          {apiError && (
            <div className="api-error">
              <span>⚠</span> {apiError}
            </div>
          )}

          {loading && (
            <div className="res-box">
              <div className="loader">
                <div className="dots">
                  <div className="dot" /><div className="dot" /><div className="dot" />
                </div>
                <span className="loader-txt">{loaderMsg[loadingType]}</span>
              </div>
            </div>
          )}

          {result && !loading && (
            <div className="res-box">
              <div className="res-hd">
                <span className="res-badge">{typeIcons[result.type]}</span>
                <button className="btn btn-sm btn-ghost" onClick={copyResult}>
                  {copied ? "✓ Copié" : "Copier"}
                </button>
              </div>
              <ResultBody text={result.content} />
            </div>
          )}
        </main>

        <footer className="dash-foot">
          <span>étude.ai — fait avec ❤️ pour les étudiants</span>
        </footer>
      </div>
    </>
  );
}
