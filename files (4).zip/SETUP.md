# 🔧 Guide d'installation — étude.ai

## Le problème qui était là

Le site utilisait `model: 'anthropic/claude-sonnet-4-20250514'` (une chaîne de texte),
mais le **provider `@ai-sdk/anthropic` n'était pas installé** — c'était les "exécuteurs" manquants.

## Les 5 fichiers à remplacer / ajouter dans ton projet

```
ton-projet/
├── lib/
│   └── ai.ts                          ← NOUVEAU  (l'exécuteur IA)
├── app/api/
│   ├── chat/route.ts                  ← REMPLACÉ (importe l'exécuteur)
│   └── quiz/generate/route.ts         ← REMPLACÉ (importe l'exécuteur)
├── package.json                       ← REMPLACÉ (@ai-sdk/anthropic ajouté)
├── .env.local.example                 ← NOUVEAU  (modèle de config)
└── supabase-schema.sql                ← NOUVEAU  (schéma base de données)
```

---

## Étape 1 — Copie les fichiers

Remplace les fichiers dans ton projet par ceux de ce dossier.

---

## Étape 2 — Installe les dépendances

```bash
pnpm install
# ou
npm install
```

---

## Étape 3 — Configure les variables d'environnement

```bash
cp .env.local.example .env.local
```

Ouvre `.env.local` et remplis :

### 🤖 Clé Anthropic (IA)
1. Va sur [console.anthropic.com](https://console.anthropic.com)
2. **API Keys** → **Create Key**
3. Copie la clé `sk-ant-...`
4. Colle dans `.env.local` : `ANTHROPIC_API_KEY=sk-ant-...`

### 🗄️ Clés Supabase (Auth + BDD)
1. Va sur [supabase.com](https://supabase.com) → ton projet
2. **Settings** → **API**
3. Copie **Project URL** → `NEXT_PUBLIC_SUPABASE_URL`
4. Copie **anon public** → `NEXT_PUBLIC_SUPABASE_ANON_KEY`

---

## Étape 4 — Crée la table Supabase

1. Sur [supabase.com](https://supabase.com) → ton projet
2. **SQL Editor** → **New query**
3. Colle le contenu de `supabase-schema.sql`
4. Clique **Run**

---

## Étape 5 — Lance en local

```bash
pnpm dev
# → http://localhost:3000
```

---

## Étape 6 — Déployer sur Vercel

```bash
git add .
git commit -m "fix: add AI executor and env config"
git push origin main
```

Sur [vercel.com](https://vercel.com) → ton projet → **Settings** → **Environment Variables** :

| Nom                          | Valeur                    |
|------------------------------|---------------------------|
| `ANTHROPIC_API_KEY`          | `sk-ant-...`              |
| `NEXT_PUBLIC_SUPABASE_URL`   | `https://xxx.supabase.co` |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | `eyJ...`               |

Puis **Deployments** → **Redeploy** (ou push un nouveau commit).

---

## En résumé — ce qui était cassé

| Avant ❌ | Après ✅ |
|----------|----------|
| `model: 'anthropic/claude-sonnet-4-20250514'` (chaîne de texte non résolue) | `model: claude('claude-sonnet-4-20250514')` via l'exécuteur |
| `@ai-sdk/anthropic` absent du package.json | `@ai-sdk/anthropic` installé |
| Pas de fichier `lib/ai.ts` | `lib/ai.ts` crée et configure l'exécuteur |
| Variables d'env non documentées | `.env.local.example` complet |
| Table Supabase non créée | `supabase-schema.sql` prêt à coller |
