import { generateText, Output } from 'ai'
import { z } from 'zod'
import { createClient } from '@/lib/supabase/server'
import { claude } from '@/lib/ai'   // ← l'exécuteur IA

const QuizSchema = z.object({
  questions: z.array(
    z.object({
      question:     z.string().describe('La question du quiz'),
      options:      z.array(z.string()).length(4).describe('4 options de réponse'),
      correctIndex: z.number().min(0).max(3).describe('Index de la bonne réponse (0-3)'),
      explanation:  z.string().describe('Explication de la bonne réponse'),
    })
  ),
})

const subjectContexts: Record<string, string> = {
  maths:         'mathématiques (algèbre, géométrie, analyse, statistiques)',
  sciences:      'sciences (physique, chimie, SVT)',
  francais:      'français (grammaire, littérature, vocabulaire)',
  anglais:       'anglais (grammaire, vocabulaire, expressions)',
  'histoire-geo':'histoire et géographie',
}

const levelContexts: Record<string, string> = {
  college:   'niveau collège (6ème à 3ème)',
  lycee:     'niveau lycée (2nde à Terminale)',
  superieur: 'niveau études supérieures',
}

export const maxDuration = 60

export async function POST(req: Request) {
  const { subject, level, topic, questionCount = 5 } = await req.json()

  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) {
    return Response.json({ error: 'Non authentifié' }, { status: 401 })
  }

  const subjectContext = subjectContexts[subject] || 'général'
  const levelContext   = levelContexts[level]   || 'lycée'

  const prompt = `Génère un quiz de ${questionCount} questions à choix multiples en ${subjectContext} pour un étudiant de ${levelContext}.
${topic ? `Le quiz doit porter sur le sujet suivant: ${topic}` : 'Choisis des sujets variés et pertinents.'}

Pour chaque question:
- La question doit être claire et précise
- Propose exactement 4 options de réponse
- Une seule réponse est correcte
- L'explication doit aider à comprendre pourquoi c'est la bonne réponse

Les questions doivent être progressives en difficulté.`

  try {
    const result = await generateText({
      model: claude('claude-sonnet-4-20250514'),   // ← modèle branché sur l'exécuteur
      prompt,
      output: Output.object({ schema: QuizSchema }),
    })

    return Response.json({ quiz: result.output })
  } catch (error) {
    console.error('Quiz generation error:', error)
    return Response.json({ error: 'Erreur lors de la génération du quiz' }, { status: 500 })
  }
}
