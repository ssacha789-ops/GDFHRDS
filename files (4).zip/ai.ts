import { createAnthropic } from '@ai-sdk/anthropic'

if (!process.env.ANTHROPIC_API_KEY) {
  throw new Error('❌ ANTHROPIC_API_KEY est manquant dans les variables d\'environnement.')
}

/**
 * Exécuteur IA — Anthropic Claude
 * Utilisé par toutes les routes API : chat, quiz, résumé, etc.
 *
 * Usage :
 *   import { claude } from '@/lib/ai'
 *   model: claude('claude-sonnet-4-20250514')
 */
export const claude = createAnthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
})
