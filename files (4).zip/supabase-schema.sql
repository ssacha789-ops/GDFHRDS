-- ══════════════════════════════════════════════════════════
-- SCHÉMA SUPABASE — étude.ai
-- ══════════════════════════════════════════════════════════
-- Colle ce SQL dans : Supabase → SQL Editor → New query → Run
-- ══════════════════════════════════════════════════════════

-- Table des résultats de quiz
create table if not exists public.quiz_results (
  id              uuid primary key default gen_random_uuid(),
  user_id         uuid not null references auth.users(id) on delete cascade,
  subject         text not null,
  topic           text,
  score           integer not null,
  total_questions integer not null,
  questions       jsonb,
  created_at      timestamptz default now()
);

-- Index pour requêtes par utilisateur
create index if not exists quiz_results_user_id_idx on public.quiz_results(user_id);

-- Sécurité : chaque utilisateur ne voit que ses propres résultats
alter table public.quiz_results enable row level security;

create policy "Users can read own results"
  on public.quiz_results for select
  using (auth.uid() = user_id);

create policy "Users can insert own results"
  on public.quiz_results for insert
  with check (auth.uid() = user_id);

create policy "Users can delete own results"
  on public.quiz_results for delete
  using (auth.uid() = user_id);
